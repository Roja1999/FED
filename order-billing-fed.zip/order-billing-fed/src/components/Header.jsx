import React from 'react';
import '../styles/Header.css';

const Header = () => (
    <header className="header">
        {/* Main Header Content */}
        <div className="header-content">
            <img src="images/header-img.png" alt="Logo" className="header-logo" />
        </div>
    </header>
);

export default Header;