import React, { createContext, useReducer, useEffect } from 'react';
import orderReducer, {
    setOrders,
    addOrder,
    deleteOrder,
    updateOrder,
    setEditMode,
    clearEditMode,
    setError,
} from '../redux/reducers';

export const OrderContext = createContext();

const OrderProvider = ({ children }) => {
    const [state, dispatch] = useReducer(orderReducer, {
        orders: [],
        error: null,
        editMode: null,
    });

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/getOrders');
            const orders = await response.json();
            dispatch(setOrders(orders));
        } catch (error) {
            dispatch(setError('Unable to fetch orders'));
        }
    };

    const addOrderToState = async (order) => {
        try {
            const response = await fetch('http://localhost:9090/order-billing-ws/addOrder', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    orderName: order.orderName,
                    price: parseFloat(order.price),
                    isDiscounted: order.promo
                }),
            });
            const newOrder = await response.json();
            console.log("newOrder", newOrder);
            // Update the state immediately
            dispatch(addOrder(newOrder));
        } catch (error) {
            dispatch(setError('Unable to add order'));
        }
    };

    const deleteOrderFromState = async (orderId) => {
        try {
            await fetch(`http://localhost:9090/order-billing-ws/deleteOrder/${orderId}`, {
                method: 'DELETE',
            });
            dispatch(deleteOrder(orderId));
        } catch (error) {
            dispatch(setError('Unable to delete order'));
        }
    };

    const updateOrderInState = async (order) => {
        try {
            const response = await fetch(`http://localhost:9090/order-billing-ws/updateOrder/${order.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(order),
            });
            const updatedOrder = await response.json();
            dispatch(updateOrder(updatedOrder));
        } catch (error) {
            dispatch(setError('Unable to update order'));
        }
    };

    return (
        <OrderContext.Provider
            value={{
                orders: state.orders,
                addOrder: addOrderToState,
                deleteOrder: deleteOrderFromState,
                updateOrder: updateOrderInState,
                setEditMode: (order) => dispatch(setEditMode(order)),
                clearEditMode: () => dispatch(clearEditMode()),
                editMode: state.editMode,
            }}
        >
            {children}
        </OrderContext.Provider>
    );
};

export default OrderProvider;